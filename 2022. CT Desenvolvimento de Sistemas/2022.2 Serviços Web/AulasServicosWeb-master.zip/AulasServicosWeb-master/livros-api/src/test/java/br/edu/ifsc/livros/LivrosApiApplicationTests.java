package br.edu.ifsc.livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivrosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
