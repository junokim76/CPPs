package br.edu.ifsc.calculadora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeFuncionarioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
