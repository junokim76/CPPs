package br.edu.ifsc.primeiroprojeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroprojetoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiroprojetoApiApplication.class, args);
	}

}
