package br.edu.ifsc.segundoexemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundoexemploApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
