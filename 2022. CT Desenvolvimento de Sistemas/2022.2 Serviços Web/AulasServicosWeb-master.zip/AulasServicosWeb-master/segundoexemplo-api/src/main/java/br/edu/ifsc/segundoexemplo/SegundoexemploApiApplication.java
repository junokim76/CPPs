package br.edu.ifsc.segundoexemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoexemploApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoexemploApiApplication.class, args);
	}

}
