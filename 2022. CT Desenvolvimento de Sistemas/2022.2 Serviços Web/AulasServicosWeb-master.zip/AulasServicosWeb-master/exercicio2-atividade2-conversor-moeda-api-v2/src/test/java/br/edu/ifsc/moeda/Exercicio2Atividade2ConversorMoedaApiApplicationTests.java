package br.edu.ifsc.moeda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio2Atividade2ConversorMoedaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
