package br.edu.ifsc.primeiroprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroprojetoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
