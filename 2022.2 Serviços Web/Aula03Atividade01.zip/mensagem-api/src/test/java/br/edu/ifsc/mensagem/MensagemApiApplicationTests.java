package br.edu.ifsc.mensagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MensagemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
